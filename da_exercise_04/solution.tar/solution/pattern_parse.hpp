#pragma once

void PatternParse(std::vector<unsigned int>&);
