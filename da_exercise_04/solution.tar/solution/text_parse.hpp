#pragma once

void TextParse(std::vector<std::pair<std::pair<size_t,size_t>, unsigned int>>&);
